class PocoTheme {

}

$(document).ready(function () {
    new PocoTheme();
})
