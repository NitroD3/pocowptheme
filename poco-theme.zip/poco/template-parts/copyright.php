<div class="copyright-bar">
	<div class="container">
		<div class="row  align-items-center">
			<div class="column-12">
				<?php poco_credit(); ?>
			</div>
		</div>
	</div>
</div>
